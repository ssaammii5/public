// Lab 08 - implementing predictive parser for a mini language

#include <stdio.h>
#include <string.h>

// Predictive parser for a mini language
// Non-terminals: S, A, B, C
// Terminals: a, b, c, d

char table[4][5][10] = {
    // S
    {"A", "", "", "", ""},
    // A
    {"Bb", "", "", "Cd", ""},
    // B
    {"aB", "@", "", "", ""},
    // C
    {"", "", "Cc", "", "@"}
};

char stack[100];
char input[100];
int top = -1;
int ip = 0;

char pop() {
    if(top == -1) return -1;
    return stack[top--];
}

void push(char c) {
    stack[++top] = c;
}

int get_non_terminal_index(char c) {
    switch(c) {
        case 'S': return 0;
        case 'A': return 1;
        case 'B': return 2;
        case 'C': return 3;
        default: return -1;
    }
}

int get_terminal_index(char c) {
    switch(c) {
        case 'a': return 0;
        case 'b': return 1;
        case 'c': return 2;
        case 'd': return 3;
        case '$': return 4;
        default: return -1;
    }
}

void parse() {
    push('$');
    push('S');

    printf("\nStack\tInput\tAction\n");

    while(top != -1) {
        // Print current stack and remaining input
        printf("\n");
        for(int i = 0; i <= top; i++)
            printf("%c", stack[i]);
        printf("\t%s\t", &input[ip]);

        // If top of stack is same as current input symbol, match and advance
        if(stack[top] == input[ip]) {
            printf("Match %c", input[ip]);
            pop();
            ip++;
            continue;
        }

        // If epsilon production (@)
        if(stack[top] == '@') {
            printf("Pop @");
            pop();
            continue;
        }

        // Lookup in parse table
        int row = get_non_terminal_index(stack[top]);
        int col = get_terminal_index(input[ip]);

        if(row == -1 || col == -1 || table[row][col][0] == '\0') {
            printf("Error: No production found");
            return;
        }

        // Production found, replace stack top
        printf("Apply %c -> %s", stack[top], table[row][col]);
        char top_symbol = pop();

        // Push production in reverse order
        for(int i = strlen(table[row][col])-1; i >= 0; i--) {
            push(table[row][col][i]);
        }
    }

    if(input[ip] == '$')
        printf("\n\nInput string accepted!\n");
    else
        printf("\n\nError: Parsing failed!\n");
}

void main() {
    printf("Enter input string ending with $: ");
    scanf("%s", input);

    parse();
}
