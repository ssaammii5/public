// Lab 14 - construct a syntax tree for a given input

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Node structure for syntax tree
typedef struct node {
    char type;  // 'O': operator, 'I': identifier, 'C': constant
    char value[10];
    struct node *left;
    struct node *right;
} Node;

// Stack for expression parsing
typedef struct {
    Node* data[100];
    int top;
} Stack;

// Initialize empty stack
void init_stack(Stack *s) {
    s->top = -1;
}

// Push operation for stack
void push(Stack *s, Node *item) {
    s->data[++s->top] = item;
}

// Pop operation for stack
Node* pop(Stack *s) {
    return s->data[s->top--];
}

// Create a new node
Node* create_node(char type, char *value) {
    Node *new_node = (Node*)malloc(sizeof(Node));
    if(new_node == NULL) {
        printf("Memory allocation failed!");
        exit(1);
    }

    new_node->type = type;
    strcpy(new_node->value, value);
    new_node->left = NULL;
    new_node->right = NULL;

    return new_node;
}

// Check if character is operator
int is_operator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

// Get operator precedence
int precedence(char op) {
    switch(op) {
        case '+':
        case '-':
            return 1;
        case '*':
        case '/':
            return 2;
        default:
            return 0;
    }
}

// Build syntax tree from infix expression
Node* build_syntax_tree(char *expr) {
    Stack operands;
    Stack operators;

    init_stack(&operands);
    init_stack(&operators);

    char token[10] = "";
    int token_index = 0;

    for(int i = 0; expr[i] != '\0'; i++) {
        // Skip spaces
        if(expr[i] == ' ')
            continue;

        // Handle parentheses
        if(expr[i] == '(') {
            push(&operators, create_node('(', "("));
        }
        else if(expr[i] == ')') {
            // If there was a token being formed, add it as operand
            if(token_index > 0) {
                token[token_index] = '\0';
                push(&operands, create_node('I', token));
                token_index = 0;
            }

            while(operators.top != -1 && operators.data[operators.top]->type != '(') {
                Node *op_node = pop(&operators);
                Node *right = pop(&operands);
                Node *left = pop(&operands);

                op_node->right = right;
                op_node->left = left;

                push(&operands, op_node);
            }

            // Pop the '('
            if(operators.top != -1)
                pop(&operators);
        }
        // Handle operators
        else if(is_operator(expr[i])) {
            // If there was a token being formed, add it as operand
            if(token_index > 0) {
                token[token_index] = '\0';
                push(&operands, create_node('I', token));
                token_index = 0;
            }

            // Handle operator precedence
            while(operators.top != -1 &&
                  operators.data[operators.top]->type != '(' &&
                  precedence(operators.data[operators.top]->value[0]) >= precedence(expr[i])) {
                Node *op_node = pop(&operators);
                Node *right = pop(&operands);
                Node *left = pop(&operands);

                op_node->right = right;
                op_node->left = left;

                push(&operands, op_node);
            }

            char op_str[2] = {expr[i], '\0'};
            push(&operators, create_node('O', op_str));
        }
        // Handle operands (identifiers and constants)
        else {
            token[token_index++] = expr[i];
        }
    }

    // If there was a token being formed, add it as operand
    if(token_index > 0) {
        token[token_index] = '\0';
        push(&operands, create_node('I', token));
    }

    // Process remaining operators
    while(operators.top != -1) {
        Node *op_node = pop(&operators);
        Node *right = pop(&operands);
        Node *left = pop(&operands);

        op_node->right = right;
        op_node->left = left;

        push(&operands, op_node);
    }

    // The final syntax tree
    return pop(&operands);
}

// Print syntax tree using inorder traversal
void print_tree(Node *root, int level) {
    if(root == NULL)
        return;

    print_tree(root->right, level + 1);

    for(int i = 0; i < level; i++)
        printf("    ");

    printf("%s\n", root->value);

    print_tree(root->left, level + 1);
}

void main() {
    char expression[100];

    printf("Enter an arithmetic expression: ");
    gets(expression);

    Node *root = build_syntax_tree(expression);

    printf("\nSyntax Tree:\n");
    print_tree(root, 0);
}
