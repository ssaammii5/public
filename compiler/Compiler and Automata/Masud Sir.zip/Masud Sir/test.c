#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Global variables
char input[100];
int position = 0;
char lookahead;

// Function prototypes
void match(char expected);
void error();
void E();
void E_prime();
void T();
void T_prime();
void F();
void advance();

// Grammar implemented:
// E -> T E'
// E' -> + T E' | ε
// T -> F T'
// T' -> * F T' | ε
// F -> ( E ) | id

int main() {
    printf("Top-Down Parser for Grammar:\n");
    printf("E -> T E'\n");
    printf("E' -> + T E' | ε\n");
    printf("T -> F T'\n");
    printf("T' -> * F T' | ε\n");
    printf("F -> ( E ) | id\n\n");

    printf("Enter an expression (use lowercase letters for identifiers): ");
    fgets(input, sizeof(input), stdin);

    // Remove newline character if present
    int len = strlen(input);
    if (len > 0 && input[len-1] == '\n') {
        input[len-1] = '\0';
    }

    // Initialize lookahead
    lookahead = input[position];

    // Start parsing
    E();

    if (lookahead == '\0') {
        printf("\nParsing completed successfully!\n");
        printf("The input string \"%s\" is accepted by the grammar.\n", input);
    } else {
        error();
    }

    return 0;
}

void advance() {
    position++;
    lookahead = input[position];
}

void match(char expected) {
    if (lookahead == expected) {
        printf("Matched: %c\n", expected);
        advance();
    } else {
        error();
    }
}

void error() {
    printf("\nSyntax Error at position %d: Unexpected symbol '%c'\n", position, lookahead);
    printf("Parsing failed!\n");
    exit(1);
}

// E -> T E'
void E() {
    printf("Entering E -> T E'\n");
    T();
    E_prime();
    printf("Exiting E\n");
}

// E' -> + T E' | ε
void E_prime() {
    printf("Entering E'\n");
    if (lookahead == '+') {
        match('+');
        T();
        E_prime();
    } else {
        // ε production - do nothing
        printf("E' -> ε\n");
    }
    printf("Exiting E'\n");
}

// T -> F T'
void T() {
    printf("Entering T -> F T'\n");
    F();
    T_prime();
    printf("Exiting T\n");
}

// T' -> * F T' | ε
void T_prime() {
    printf("Entering T'\n");
    if (lookahead == '*') {
        match('*');
        F();
        T_prime();
    } else {
        // ε production - do nothing
        printf("T' -> ε\n");
    }
    printf("Exiting T'\n");
}

// F -> ( E ) | id
void F() {
    printf("Entering F\n");
    if (lookahead == '(') {
        match('(');
        E();
        match(')');
    } else if (isalpha(lookahead) || isdigit(lookahead)) {
        printf("F -> id\n");
        printf("Matched: %c (identifier)\n", lookahead);
        advance();
    } else {
        error();
    }
    printf("Exiting F\n");
}
