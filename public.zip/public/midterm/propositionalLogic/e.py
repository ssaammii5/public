from logic import *
p,q = vars('p','q')
f = (p&q)
print("I am a rock and I am an island.\n")
print("P: I am a rock\nQ: I am an island\n")
f.print_truth_table()